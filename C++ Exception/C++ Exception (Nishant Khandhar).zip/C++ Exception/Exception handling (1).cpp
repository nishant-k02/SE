#include <iostream>

using namespace std;

int main()
{
   int a, b;
   
   cout<<"Enter 2 numbers: "<<endl;
   cin>>a,b;
   
   int c = a/b;
   
   cout<<"The Division is: "<<c;
   
    return 0;
}
